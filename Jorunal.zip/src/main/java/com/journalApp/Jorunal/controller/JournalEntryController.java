package com.journalApp.Jorunal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.journalApp.Jorunal.entity.JournalEntry;
import com.journalApp.Jorunal.service.JournalEntryService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;



@RestController
@RequestMapping("/journal")
public class JournalEntryController {

    @Autowired
    private JournalEntryService JournalEntryService;

    @PostMapping
    public boolean createEntry(@RequestBody JournalEntry myEntry) {
        JournalEntryService.saveEntry(myEntry);
        return true;
    }

}