package com.journalApp.Jorunal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JorunalAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
